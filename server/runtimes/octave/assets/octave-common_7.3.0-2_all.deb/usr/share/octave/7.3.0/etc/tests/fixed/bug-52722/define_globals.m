global a b c

