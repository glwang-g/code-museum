global a b c
