
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was SWIPLConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/cmake/swipl" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

####################################################################################

# Version information
set(SWIPL_VERSION_COUNT 3)
set(SWIPL_VERSION_MAJOR 9)
set(SWIPL_VERSION_MINOR 0)
set(SWIPL_VERSION_PATCH 4)
set(SWIPL_VERSION_STRING 9.0.4)

# Location suitable for passing to PL_initialise() as argv[0]
set(SWIPL_EXECUTABLE "${PACKAGE_PREFIX_DIR}/lib/swi-prolog/bin/x86_64-linux/swipl")

# Exported targets
include("${CMAKE_CURRENT_LIST_DIR}/SWIPLTargets.cmake")
