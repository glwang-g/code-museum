#----------------------------------------------------------------
# Generated CMake target import file for configuration "DEB".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "swipl::swipl" for configuration "DEB"
set_property(TARGET swipl::swipl APPEND PROPERTY IMPORTED_CONFIGURATIONS DEB)
set_target_properties(swipl::swipl PROPERTIES
  IMPORTED_LOCATION_DEB "${_IMPORT_PREFIX}/lib/swi-prolog/bin/x86_64-linux/swipl"
  )

list(APPEND _cmake_import_check_targets swipl::swipl )
list(APPEND _cmake_import_check_files_for_swipl::swipl "${_IMPORT_PREFIX}/lib/swi-prolog/bin/x86_64-linux/swipl" )

# Import target "swipl::libswipl" for configuration "DEB"
set_property(TARGET swipl::libswipl APPEND PROPERTY IMPORTED_CONFIGURATIONS DEB)
set_target_properties(swipl::libswipl PROPERTIES
  IMPORTED_LOCATION_DEB "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libswipl.so.9.0.4"
  IMPORTED_SONAME_DEB "libswipl.so.9"
  )

list(APPEND _cmake_import_check_targets swipl::libswipl )
list(APPEND _cmake_import_check_files_for_swipl::libswipl "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libswipl.so.9.0.4" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
