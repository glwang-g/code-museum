/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 262658
#define R_NICK "Innocent and Trusting"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "4"
#define R_MINOR  "2.2"
#define R_STATUS "Patched"
#define R_YEAR   "2022"
#define R_MONTH  "11"
#define R_DAY    "10"
#define R_SVN_REVISION 83330
#define R_FILEVERSION    4,22,83330,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
