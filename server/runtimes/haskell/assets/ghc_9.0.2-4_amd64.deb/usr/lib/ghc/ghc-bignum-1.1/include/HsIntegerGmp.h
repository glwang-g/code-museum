#pragma once

/* Whether GMP is embedded into ghc-bignum */
#define GHC_GMP_INTREE     0

/* The following values denote the GMP version used during GHC build-time */
#define GHC_GMP_VERSION_MJ 6
#define GHC_GMP_VERSION_MI 2
#define GHC_GMP_VERSION_PL 1
#define GHC_GMP_VERSION \
    (6 * 10000 + 2 * 100 + 1)

/* Whether GMP supports mpz_powm_sec */
#define HAVE_SECURE_POWM 1
