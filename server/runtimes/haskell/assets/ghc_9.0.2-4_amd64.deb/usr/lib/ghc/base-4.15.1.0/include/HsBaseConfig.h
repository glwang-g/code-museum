/* include/HsBaseConfig.h.  Generated from HsBaseConfig.h.in by configure.  */
/* include/HsBaseConfig.h.in.  Generated from configure.ac by autoheader.  */

/* The value of E2BIG. */
#define CONST_E2BIG 7

/* The value of EACCES. */
#define CONST_EACCES 13

/* The value of EADDRINUSE. */
#define CONST_EADDRINUSE 98

/* The value of EADDRNOTAVAIL. */
#define CONST_EADDRNOTAVAIL 99

/* The value of EADV. */
#define CONST_EADV 68

/* The value of EAFNOSUPPORT. */
#define CONST_EAFNOSUPPORT 97

/* The value of EAGAIN. */
#define CONST_EAGAIN 11

/* The value of EALREADY. */
#define CONST_EALREADY 114

/* The value of EBADF. */
#define CONST_EBADF 9

/* The value of EBADMSG. */
#define CONST_EBADMSG 74

/* The value of EBADRPC. */
#define CONST_EBADRPC -1

/* The value of EBUSY. */
#define CONST_EBUSY 16

/* The value of ECHILD. */
#define CONST_ECHILD 10

/* The value of ECOMM. */
#define CONST_ECOMM 70

/* The value of ECONNABORTED. */
#define CONST_ECONNABORTED 103

/* The value of ECONNREFUSED. */
#define CONST_ECONNREFUSED 111

/* The value of ECONNRESET. */
#define CONST_ECONNRESET 104

/* The value of EDEADLK. */
#define CONST_EDEADLK 35

/* The value of EDESTADDRREQ. */
#define CONST_EDESTADDRREQ 89

/* The value of EDIRTY. */
#define CONST_EDIRTY -1

/* The value of EDOM. */
#define CONST_EDOM 33

/* The value of EDQUOT. */
#define CONST_EDQUOT 122

/* The value of EEXIST. */
#define CONST_EEXIST 17

/* The value of EFAULT. */
#define CONST_EFAULT 14

/* The value of EFBIG. */
#define CONST_EFBIG 27

/* The value of EFTYPE. */
#define CONST_EFTYPE -1

/* The value of EHOSTDOWN. */
#define CONST_EHOSTDOWN 112

/* The value of EHOSTUNREACH. */
#define CONST_EHOSTUNREACH 113

/* The value of EIDRM. */
#define CONST_EIDRM 43

/* The value of EILSEQ. */
#define CONST_EILSEQ 84

/* The value of EINPROGRESS. */
#define CONST_EINPROGRESS 115

/* The value of EINTR. */
#define CONST_EINTR 4

/* The value of EINVAL. */
#define CONST_EINVAL 22

/* The value of EIO. */
#define CONST_EIO 5

/* The value of EISCONN. */
#define CONST_EISCONN 106

/* The value of EISDIR. */
#define CONST_EISDIR 21

/* The value of ELOOP. */
#define CONST_ELOOP 40

/* The value of EMFILE. */
#define CONST_EMFILE 24

/* The value of EMLINK. */
#define CONST_EMLINK 31

/* The value of EMSGSIZE. */
#define CONST_EMSGSIZE 90

/* The value of EMULTIHOP. */
#define CONST_EMULTIHOP 72

/* The value of ENAMETOOLONG. */
#define CONST_ENAMETOOLONG 36

/* The value of ENETDOWN. */
#define CONST_ENETDOWN 100

/* The value of ENETRESET. */
#define CONST_ENETRESET 102

/* The value of ENETUNREACH. */
#define CONST_ENETUNREACH 101

/* The value of ENFILE. */
#define CONST_ENFILE 23

/* The value of ENOBUFS. */
#define CONST_ENOBUFS 105

/* The value of ENOCIGAR. */
#define CONST_ENOCIGAR -1

/* The value of ENODATA. */
#define CONST_ENODATA 61

/* The value of ENODEV. */
#define CONST_ENODEV 19

/* The value of ENOENT. */
#define CONST_ENOENT 2

/* The value of ENOEXEC. */
#define CONST_ENOEXEC 8

/* The value of ENOLCK. */
#define CONST_ENOLCK 37

/* The value of ENOLINK. */
#define CONST_ENOLINK 67

/* The value of ENOMEM. */
#define CONST_ENOMEM 12

/* The value of ENOMSG. */
#define CONST_ENOMSG 42

/* The value of ENONET. */
#define CONST_ENONET 64

/* The value of ENOPROTOOPT. */
#define CONST_ENOPROTOOPT 92

/* The value of ENOSPC. */
#define CONST_ENOSPC 28

/* The value of ENOSR. */
#define CONST_ENOSR 63

/* The value of ENOSTR. */
#define CONST_ENOSTR 60

/* The value of ENOSYS. */
#define CONST_ENOSYS 38

/* The value of ENOTBLK. */
#define CONST_ENOTBLK 15

/* The value of ENOTCONN. */
#define CONST_ENOTCONN 107

/* The value of ENOTDIR. */
#define CONST_ENOTDIR 20

/* The value of ENOTEMPTY. */
#define CONST_ENOTEMPTY 39

/* The value of ENOTSOCK. */
#define CONST_ENOTSOCK 88

/* The value of ENOTSUP. */
#define CONST_ENOTSUP 95

/* The value of ENOTTY. */
#define CONST_ENOTTY 25

/* The value of ENXIO. */
#define CONST_ENXIO 6

/* The value of EOPNOTSUPP. */
#define CONST_EOPNOTSUPP 95

/* The value of EPERM. */
#define CONST_EPERM 1

/* The value of EPFNOSUPPORT. */
#define CONST_EPFNOSUPPORT 96

/* The value of EPIPE. */
#define CONST_EPIPE 32

/* The value of EPROCLIM. */
#define CONST_EPROCLIM -1

/* The value of EPROCUNAVAIL. */
#define CONST_EPROCUNAVAIL -1

/* The value of EPROGMISMATCH. */
#define CONST_EPROGMISMATCH -1

/* The value of EPROGUNAVAIL. */
#define CONST_EPROGUNAVAIL -1

/* The value of EPROTO. */
#define CONST_EPROTO 71

/* The value of EPROTONOSUPPORT. */
#define CONST_EPROTONOSUPPORT 93

/* The value of EPROTOTYPE. */
#define CONST_EPROTOTYPE 91

/* The value of ERANGE. */
#define CONST_ERANGE 34

/* The value of EREMCHG. */
#define CONST_EREMCHG 78

/* The value of EREMOTE. */
#define CONST_EREMOTE 66

/* The value of EROFS. */
#define CONST_EROFS 30

/* The value of ERPCMISMATCH. */
#define CONST_ERPCMISMATCH -1

/* The value of ERREMOTE. */
#define CONST_ERREMOTE -1

/* The value of ESHUTDOWN. */
#define CONST_ESHUTDOWN 108

/* The value of ESOCKTNOSUPPORT. */
#define CONST_ESOCKTNOSUPPORT 94

/* The value of ESPIPE. */
#define CONST_ESPIPE 29

/* The value of ESRCH. */
#define CONST_ESRCH 3

/* The value of ESRMNT. */
#define CONST_ESRMNT 69

/* The value of ESTALE. */
#define CONST_ESTALE 116

/* The value of ETIME. */
#define CONST_ETIME 62

/* The value of ETIMEDOUT. */
#define CONST_ETIMEDOUT 110

/* The value of ETOOMANYREFS. */
#define CONST_ETOOMANYREFS 109

/* The value of ETXTBSY. */
#define CONST_ETXTBSY 26

/* The value of EUSERS. */
#define CONST_EUSERS 87

/* The value of EWOULDBLOCK. */
#define CONST_EWOULDBLOCK 11

/* The value of EXDEV. */
#define CONST_EXDEV 18

/* The value of O_BINARY. */
#define CONST_O_BINARY 0

/* The value of SIGINT. */
#define CONST_SIGINT 2

/* Define to 1 if you have the `clock_gettime' function. */
#define HAVE_CLOCK_GETTIME 1

/* Define to 1 if you have the <ctype.h> header file. */
#define HAVE_CTYPE_H 1

/* Define if you have epoll support. */
#define HAVE_EPOLL 1

/* Define to 1 if you have the `epoll_ctl' function. */
#define HAVE_EPOLL_CTL 1

/* Define to 1 if you have the <errno.h> header file. */
#define HAVE_ERRNO_H 1

/* Define to 1 if you have the `eventfd' function. */
#define HAVE_EVENTFD 1

/* Define to 1 if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define if you have flock support. */
#define HAVE_FLOCK 1

/* Define to 1 if you have the `ftruncate' function. */
#define HAVE_FTRUNCATE 1

/* Define to 1 if you have the `getclock' function. */
/* #undef HAVE_GETCLOCK */

/* Define to 1 if you have the `getrusage' function. */
#define HAVE_GETRUSAGE 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `iswspace' function. */
#define HAVE_ISWSPACE 1

/* Define to 1 if you have the `kevent' function. */
/* #undef HAVE_KEVENT */

/* Define to 1 if you have the `kevent64' function. */
/* #undef HAVE_KEVENT64 */

/* Define if you have kqueue support. */
/* #undef HAVE_KQUEUE */

/* Define to 1 if you have the <langinfo.h> header file. */
#define HAVE_LANGINFO_H 1

/* Define to 1 if you have libcharset. */
/* #undef HAVE_LIBCHARSET */

/* Define to 1 if you have the `rt' library (-lrt). */
#define HAVE_LIBRT 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* Define to 1 if the system has the type `long long'. */
#define HAVE_LONG_LONG 1

/* Define to 1 if you have the `lstat' function. */
#define HAVE_LSTAT 1

/* Define to 1 if you have the <minix/config.h> header file. */
/* #undef HAVE_MINIX_CONFIG_H */

/* Define if you have open file descriptor lock support. */
#define HAVE_OFD_LOCKING 1

/* Define if you have poll support. */
#define HAVE_POLL 1

/* Define to 1 if you have the <poll.h> header file. */
#define HAVE_POLL_H 1

/* Define to 1 if you have the <signal.h> header file. */
#define HAVE_SIGNAL_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/epoll.h> header file. */
#define HAVE_SYS_EPOLL_H 1

/* Define to 1 if you have the <sys/eventfd.h> header file. */
#define HAVE_SYS_EVENTFD_H 1

/* Define to 1 if you have the <sys/event.h> header file. */
/* #undef HAVE_SYS_EVENT_H */

/* Define to 1 if you have the <sys/file.h> header file. */
#define HAVE_SYS_FILE_H 1

/* Define to 1 if you have the <sys/resource.h> header file. */
#define HAVE_SYS_RESOURCE_H 1

/* Define to 1 if you have the <sys/select.h> header file. */
#define HAVE_SYS_SELECT_H 1

/* Define to 1 if you have the <sys/socket.h> header file. */
#define HAVE_SYS_SOCKET_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/syscall.h> header file. */
#define HAVE_SYS_SYSCALL_H 1

/* Define to 1 if you have the <sys/timeb.h> header file. */
#define HAVE_SYS_TIMEB_H 1

/* Define to 1 if you have the <sys/timers.h> header file. */
/* #undef HAVE_SYS_TIMERS_H */

/* Define to 1 if you have the <sys/times.h> header file. */
#define HAVE_SYS_TIMES_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/utsname.h> header file. */
#define HAVE_SYS_UTSNAME_H 1

/* Define to 1 if you have the <sys/wait.h> header file. */
#define HAVE_SYS_WAIT_H 1

/* Define to 1 if you have the <termios.h> header file. */
#define HAVE_TERMIOS_H 1

/* Define to 1 if you have the `times' function. */
#define HAVE_TIMES 1

/* Define to 1 if you have the <time.h> header file. */
#define HAVE_TIME_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `unsetenv' function. */
#define HAVE_UNSETENV 1

/* Define to 1 if you have the <utime.h> header file. */
#define HAVE_UTIME_H 1

/* Define to 1 if you have the <wchar.h> header file. */
#define HAVE_WCHAR_H 1

/* Define to 1 if you have the <wctype.h> header file. */
#define HAVE_WCTYPE_H 1

/* Define to 1 if you have the <windows.h> header file. */
/* #undef HAVE_WINDOWS_H */

/* Define to 1 if you have the <winsock.h> header file. */
/* #undef HAVE_WINSOCK_H */

/* Define to 1 if you have the `_chsize' function. */
/* #undef HAVE__CHSIZE */

/* Define to Haskell type for blkcnt_t */
#define HTYPE_BLKCNT_T Int64

/* Define to Haskell type for blksize_t */
#define HTYPE_BLKSIZE_T Int64

/* Define to Haskell type for bool */
#define HTYPE_BOOL Word8

/* Define to Haskell type for cc_t */
#define HTYPE_CC_T Word8

/* Define to Haskell type for char */
#define HTYPE_CHAR Int8

/* Define to Haskell type for clockid_t */
#define HTYPE_CLOCKID_T Int32

/* Define to Haskell type for clock_t */
#define HTYPE_CLOCK_T Int64

/* Define to Haskell type for dev_t */
#define HTYPE_DEV_T Word64

/* Define to Haskell type for double */
#define HTYPE_DOUBLE Double

/* Define to Haskell type for float */
#define HTYPE_FLOAT Float

/* Define to Haskell type for fsblkcnt_t */
#define HTYPE_FSBLKCNT_T Word64

/* Define to Haskell type for fsfilcnt_t */
#define HTYPE_FSFILCNT_T Word64

/* Define to Haskell type for gid_t */
#define HTYPE_GID_T Word32

/* Define to Haskell type for id_t */
#define HTYPE_ID_T Word32

/* Define to Haskell type for ino_t */
#define HTYPE_INO_T Word64

/* Define to Haskell type for int */
#define HTYPE_INT Int32

/* Define to Haskell type for intmax_t */
#define HTYPE_INTMAX_T Int64

/* Define to Haskell type for intptr_t */
#define HTYPE_INTPTR_T Int64

/* Define to Haskell type for key_t */
#define HTYPE_KEY_T Int32

/* Define to Haskell type for long */
#define HTYPE_LONG Int64

/* Define to Haskell type for long long */
#define HTYPE_LONG_LONG Int64

/* Define to Haskell type for mode_t */
#define HTYPE_MODE_T Word32

/* Define to Haskell type for nfds_t */
#define HTYPE_NFDS_T Word64

/* Define to Haskell type for nlink_t */
#define HTYPE_NLINK_T Word64

/* Define to Haskell type for off_t */
#define HTYPE_OFF_T Int64

/* Define to Haskell type for pid_t */
#define HTYPE_PID_T Int32

/* Define to Haskell type for ptrdiff_t */
#define HTYPE_PTRDIFF_T Int64

/* Define to Haskell type for rlim_t */
#define HTYPE_RLIM_T Word64

/* Define to Haskell type for short */
#define HTYPE_SHORT Int16

/* Define to Haskell type for signed char */
#define HTYPE_SIGNED_CHAR Int8

/* Define to Haskell type for sig_atomic_t */
#define HTYPE_SIG_ATOMIC_T Int32

/* Define to Haskell type for size_t */
#define HTYPE_SIZE_T Word64

/* Define to Haskell type for socklen_t */
#define HTYPE_SOCKLEN_T Word32

/* Define to Haskell type for speed_t */
#define HTYPE_SPEED_T Word32

/* Define to Haskell type for ssize_t */
#define HTYPE_SSIZE_T Int64

/* Define to Haskell type for suseconds_t */
#define HTYPE_SUSECONDS_T Int64

/* Define to Haskell type for tcflag_t */
#define HTYPE_TCFLAG_T Word32

/* Define to Haskell type for timer_t */
#define HTYPE_TIMER_T Ptr ()

/* Define to Haskell type for time_t */
#define HTYPE_TIME_T Int64

/* Define to Haskell type for uid_t */
#define HTYPE_UID_T Word32

/* Define to Haskell type for uintmax_t */
#define HTYPE_UINTMAX_T Word64

/* Define to Haskell type for uintptr_t */
#define HTYPE_UINTPTR_T Word64

/* Define to Haskell type for unsigned char */
#define HTYPE_UNSIGNED_CHAR Word8

/* Define to Haskell type for unsigned int */
#define HTYPE_UNSIGNED_INT Word32

/* Define to Haskell type for unsigned long */
#define HTYPE_UNSIGNED_LONG Word64

/* Define to Haskell type for unsigned long long */
#define HTYPE_UNSIGNED_LONG_LONG Word64

/* Define to Haskell type for unsigned short */
#define HTYPE_UNSIGNED_SHORT Word16

/* Define to Haskell type for useconds_t */
#define HTYPE_USECONDS_T Word32

/* Define to Haskell type for wchar_t */
#define HTYPE_WCHAR_T Int32

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "libraries@haskell.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "Haskell base package"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "Haskell base package 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "base"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* The size of `kev.filter', as computed by sizeof. */
/* #undef SIZEOF_KEV_FILTER */

/* The size of `kev.flags', as computed by sizeof. */
/* #undef SIZEOF_KEV_FLAGS */

/* The size of `struct MD5Context', as computed by sizeof. */
#define SIZEOF_STRUCT_MD5CONTEXT 88

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define if stdlib.h declares unsetenv to return void. */
/* #undef UNSETENV_RETURNS_VOID */

/* Enable extensions on AIX 3, Interix.  */
#ifndef _ALL_SOURCE
# define _ALL_SOURCE 1
#endif
/* Enable general extensions on macOS.  */
#ifndef _DARWIN_C_SOURCE
# define _DARWIN_C_SOURCE 1
#endif
/* Enable general extensions on Solaris.  */
#ifndef __EXTENSIONS__
# define __EXTENSIONS__ 1
#endif
/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif
/* Enable X/Open compliant socket functions that do not require linking
   with -lxnet on HP-UX 11.11.  */
#ifndef _HPUX_ALT_XOPEN_SOCKET_API
# define _HPUX_ALT_XOPEN_SOCKET_API 1
#endif
/* Identify the host operating system as Minix.
   This macro does not affect the system headers' behavior.
   A future release of Autoconf may stop defining this macro.  */
#ifndef _MINIX
/* # undef _MINIX */
#endif
/* Enable general extensions on NetBSD.
   Enable NetBSD compatibility extensions on Minix.  */
#ifndef _NETBSD_SOURCE
# define _NETBSD_SOURCE 1
#endif
/* Enable OpenBSD compatibility extensions on NetBSD.
   Oddly enough, this does nothing on OpenBSD.  */
#ifndef _OPENBSD_SOURCE
# define _OPENBSD_SOURCE 1
#endif
/* Define to 1 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_SOURCE
/* # undef _POSIX_SOURCE */
#endif
/* Define to 2 if needed for POSIX-compatible behavior.  */
#ifndef _POSIX_1_SOURCE
/* # undef _POSIX_1_SOURCE */
#endif
/* Enable POSIX-compatible threading on Solaris.  */
#ifndef _POSIX_PTHREAD_SEMANTICS
# define _POSIX_PTHREAD_SEMANTICS 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-5:2014.  */
#ifndef __STDC_WANT_IEC_60559_ATTRIBS_EXT__
# define __STDC_WANT_IEC_60559_ATTRIBS_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-1:2014.  */
#ifndef __STDC_WANT_IEC_60559_BFP_EXT__
# define __STDC_WANT_IEC_60559_BFP_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-2:2015.  */
#ifndef __STDC_WANT_IEC_60559_DFP_EXT__
# define __STDC_WANT_IEC_60559_DFP_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-4:2015.  */
#ifndef __STDC_WANT_IEC_60559_FUNCS_EXT__
# define __STDC_WANT_IEC_60559_FUNCS_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TS 18661-3:2015.  */
#ifndef __STDC_WANT_IEC_60559_TYPES_EXT__
# define __STDC_WANT_IEC_60559_TYPES_EXT__ 1
#endif
/* Enable extensions specified by ISO/IEC TR 24731-2:2010.  */
#ifndef __STDC_WANT_LIB_EXT2__
# define __STDC_WANT_LIB_EXT2__ 1
#endif
/* Enable extensions specified by ISO/IEC 24747:2009.  */
#ifndef __STDC_WANT_MATH_SPEC_FUNCS__
# define __STDC_WANT_MATH_SPEC_FUNCS__ 1
#endif
/* Enable extensions on HP NonStop.  */
#ifndef _TANDEM_SOURCE
# define _TANDEM_SOURCE 1
#endif
/* Enable X/Open extensions.  Define to 500 only if necessary
   to make mbstate_t available.  */
#ifndef _XOPEN_SOURCE
/* # undef _XOPEN_SOURCE */
#endif


/* Number of bits in a file offset, on hosts where this is settable. */
/* #undef _FILE_OFFSET_BITS */

/* Define for large files, on AIX-style hosts. */
/* #undef _LARGE_FILES */
